using System;
using System.Data;
using System.Data.SqlClient;
using System.Net.Http;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Net.Mail;

public static class ApiToSqlTableLoader
{
    public static void LoadJsonToSql(string apiUrl, string tableName, string primaryKey, string ifExists, SqlConnection conn, string json)
    {
        var dt = JArray.Parse(json).ToObject<DataTable>();
        if (dt == null || dt.Rows.Count == 0)
            throw new Exception("No data returned from API.");

        if (!TableExists(tableName, conn))
        {
            CreateTableFromDataTable(dt, tableName, primaryKey, conn);
        }
        else if (ifExists == "replace")
        {
            using (var cmd = new SqlCommand($"TRUNCATE TABLE [{tableName}]", conn))
                cmd.ExecuteNonQuery();
        }
        else if (ifExists == "fail")
        {
            throw new Exception($"Table [{tableName}] already exists.");
        }

        using (var bulk = new SqlBulkCopy(conn))
        {
            bulk.DestinationTableName = tableName;
            bulk.WriteToServer(dt);
        }
    }

    public static string GetJsonFromApi(string url)
    {
        using (var client = new HttpClient())
        {
            var response = client.GetAsync(url).Result;
            response.EnsureSuccessStatusCode();
            return response.Content.ReadAsStringAsync().Result;
        }
    }

    public static void Retry(Action action, int maxAttempts, int delaySeconds, out int retryCount)
    {
        retryCount = 0;
        Exception lastException = null;

        for (int attempt = 1; attempt <= maxAttempts; attempt++)
        {
            try
            {
                retryCount = attempt;
                action();
                return;
            }
            catch (Exception ex)
            {
                lastException = ex;
                if (IsTransientError(ex))
                {
                    System.Threading.Thread.Sleep(delaySeconds * 1000);
                    continue;
                }
                throw;
            }
        }

        throw new Exception($"Operation failed after {maxAttempts} retries. Last error: {lastException?.Message}", lastException);
    }

    private static bool IsTransientError(Exception ex)
    {
        return ex.Message.Contains("timeout", StringComparison.OrdinalIgnoreCase)
            || ex.Message.Contains("could not connect", StringComparison.OrdinalIgnoreCase)
            || ex.Message.Contains("deadlock", StringComparison.OrdinalIgnoreCase)
            || ex.Message.Contains("500")
            || ex.Message.Contains("503")
            || ex.Message.Contains("temporarily unavailable", StringComparison.OrdinalIgnoreCase);
    }

    public static void LogAudit(SqlConnection conn, string tableName, string apiUrl, int rowCount, string status, string message, int retryCount)
    {
        string sql = @"
            INSERT INTO ApiLoadAudit (TableName, ApiUrl, LoadTime, RowCount, Status, Message, RetryCount)
            VALUES (@TableName, @ApiUrl, GETDATE(), @RowCount, @Status, @Message, @RetryCount)";

        using (SqlCommand cmd = new SqlCommand(sql, conn))
        {
            cmd.Parameters.AddWithValue("@TableName", tableName);
            cmd.Parameters.AddWithValue("@ApiUrl", apiUrl);
            cmd.Parameters.AddWithValue("@RowCount", rowCount);
            cmd.Parameters.AddWithValue("@Status", status);
            cmd.Parameters.AddWithValue("@Message", message ?? "");
            cmd.Parameters.AddWithValue("@RetryCount", retryCount);
            cmd.ExecuteNonQuery();
        }
    }

    public static void SendEmail(string subject, string body, string to, string from, string smtpHost)
    {
        MailMessage mail = new MailMessage(from, to, subject, body);
        mail.IsBodyHtml = false;
        SmtpClient client = new SmtpClient(smtpHost);
        client.Send(mail);
    }

    private static bool TableExists(string tableName, SqlConnection conn)
    {
        string query = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @TableName";
        using (var cmd = new SqlCommand(query, conn))
        {
            cmd.Parameters.AddWithValue("@TableName", tableName);
            return (int)cmd.ExecuteScalar() > 0;
        }
    }

    private static void CreateTableFromDataTable(DataTable dt, string tableName, string primaryKey, SqlConnection conn)
    {
        var sql = new System.Text.StringBuilder($"CREATE TABLE [{tableName}] (
");
        for (int i = 0; i < dt.Columns.Count; i++)
        {
            var col = dt.Columns[i];
            string sqlType = MapType(col.DataType);
            bool isPK = col.ColumnName.Equals(primaryKey, StringComparison.OrdinalIgnoreCase);
            sql.Append($"  [{col.ColumnName}] {sqlType}");
            if (isPK) sql.Append(" PRIMARY KEY");
            sql.Append(i < dt.Columns.Count - 1 ? ",
" : "
");
        }
        sql.Append(");");

        using (var cmd = new SqlCommand(sql.ToString(), conn))
        {
            cmd.ExecuteNonQuery();
        }
    }

    private static string MapType(Type type)
    {
        type = Nullable.GetUnderlyingType(type) ?? type;

        return type switch
        {
            var t when t == typeof(int) => "INT",
            var t when t == typeof(long) => "BIGINT",
            var t when t == typeof(decimal) => "DECIMAL(18,4)",
            var t when t == typeof(float) => "FLOAT",
            var t when t == typeof(double) => "FLOAT",
            var t when t == typeof(bool) => "BIT",
            var t when t == typeof(DateTime) => "DATETIME",
            var t when t == typeof(Guid) => "UNIQUEIDENTIFIER",
            _ => "NVARCHAR(MAX)"
        };
    }
}
