# API to SQL Loader (.NET + SSIS Style)

This script is designed to:
- Pull data from a JSON API
- Deserialize it into a DataTable
- Auto-create a matching SQL Server table (if it doesn't exist)
- Insert data via SqlBulkCopy
- Log audit metadata
- Send email notifications
- Retry on transient failures

## Usage

Include `ApiToSqlTableLoader.cs` in your SSIS Script Task or C# project and call:

```csharp
ApiToSqlTableLoader.LoadJsonToSql(apiUrl, tableName, primaryKey, ifExists, conn, json);
```

Includes:
- `LogAudit()` – records audit logs to SQL
- `SendEmail()` – notifies on success/failure
- `Retry()` – auto-retries API or SQL load steps
