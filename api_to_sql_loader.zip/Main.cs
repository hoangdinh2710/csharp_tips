using System;
using System.Data.SqlClient;
using Microsoft.SqlServer.Dts.Runtime;

public class ScriptMain
{
    public void Main()
    {
        string apiUrl = "https://yourapi.com/products";
        string tableName = "Products";
        string primaryKey = "Id";
        string ifExists = "replace";

        string to = "team@yourcompany.com";
        string from = "noreply@yourcompany.com";
        string smtpHost = "smtp.yourcompany.com";
        string connStr = ((ConnectionManager)Dts.Connections["DestConn"]).ConnectionString;

        int apiRetry = 0, sqlRetry = 0;
        string json = null;

        try
        {
            ApiToSqlTableLoader.Retry(() => {
                json = ApiToSqlTableLoader.GetJsonFromApi(apiUrl);
            }, maxAttempts: 3, delaySeconds: 3, out apiRetry);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                ApiToSqlTableLoader.Retry(() => {
                    ApiToSqlTableLoader.LoadJsonToSql(apiUrl, tableName, primaryKey, ifExists, conn, json);
                }, maxAttempts: 3, delaySeconds: 3, out sqlRetry);

                ApiToSqlTableLoader.LogAudit(conn, tableName, apiUrl, -1, "Success", "Loaded successfully", apiRetry + sqlRetry);

                ApiToSqlTableLoader.SendEmail(
                    subject: $"✅ API Load Succeeded: {tableName}",
                    body: $"Data from {apiUrl} loaded successfully into {tableName} after {apiRetry + sqlRetry} attempt(s).",
                    to: to, from: from, smtpHost: smtpHost
                );
            }

            Dts.TaskResult = (int)ScriptResults.Success;
        }
        catch (Exception ex)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                ApiToSqlTableLoader.LogAudit(conn, tableName, apiUrl, 0, "Failed", ex.Message, apiRetry + sqlRetry);

                ApiToSqlTableLoader.SendEmail(
                    subject: $"❌ API Load FAILED: {tableName}",
                    body: $"API: {apiUrl}\nTable: {tableName}\nRetries: {apiRetry + sqlRetry}\n\nError: {ex.Message}",
                    to: to, from: from, smtpHost: smtpHost
                );
            }

            Dts.TaskResult = (int)ScriptResults.Failure;
        }
    }
}
